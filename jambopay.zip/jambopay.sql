-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 21, 2020 at 02:20 PM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 7.0.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jambopay`
--

-- --------------------------------------------------------

--
-- Table structure for table `agents`
--

CREATE TABLE `agents` (
  `a_id` int(11) NOT NULL,
  `agent_email_id` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `agents`
--

INSERT INTO `agents` (`a_id`, `agent_email_id`) VALUES
(1, 'agent1.sean@gmail.com'),
(3, 'agent2ng''ang''a.sean@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `agent_transactions`
--

CREATE TABLE `agent_transactions` (
  `t_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `agent_id` int(11) NOT NULL,
  `agent_transaction_cost` decimal(10,2) NOT NULL,
  `agent_commision_amt` decimal(10,2) NOT NULL,
  `jambo_commission_amt` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `agent_transactions`
--

INSERT INTO `agent_transactions` (`t_id`, `service_id`, `agent_id`, `agent_transaction_cost`, `agent_commision_amt`, `jambo_commission_amt`) VALUES
(5, 12, 1, '100.00', '2.40', '3.60'),
(6, 12, 1, '100.00', '2.40', '3.60'),
(7, 12, 1, '500.00', '12.00', '18.00'),
(8, 14, 1, '600.00', '19.20', '28.80');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `s_id` int(11) NOT NULL,
  `service_name` varchar(100) NOT NULL,
  `service_code` varchar(100) NOT NULL,
  `jambo_comm_percent` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`s_id`, `service_name`, `service_code`, `jambo_comm_percent`) VALUES
(12, 'Water', 'H20', '6.00'),
(13, 'Airtime', 'AIRTM', '10.00'),
(14, 'KPLC', 'KP', '8.00'),
(15, 'DSTV', 'STV', '5.00'),
(16, 'DSTV-2', 'STV-2', '3.00');

-- --------------------------------------------------------

--
-- Table structure for table `supporters`
--

CREATE TABLE `supporters` (
  `s_id` int(11) NOT NULL,
  `ambassador_id` varchar(100) NOT NULL,
  `supporter_id` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supporters`
--

INSERT INTO `supporters` (`s_id`, `ambassador_id`, `supporter_id`) VALUES
(2, 'shawnmbuvi@gmail.com', 'shawnmbuvi1@gmail.com'),
(3, 'seanandre30@gmail', 'supporterandre31@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `t_id` int(11) NOT NULL,
  `supporter_id` varchar(100) NOT NULL,
  `ambassador_id` varchar(100) NOT NULL,
  `service_code` varchar(100) NOT NULL,
  `transaction_cost` decimal(10,2) NOT NULL,
  `ambassador_commission` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `u_id` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `phone_no` varchar(20) NOT NULL,
  `id_number` varchar(20) NOT NULL,
  `user_type` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`u_id`, `fname`, `lname`, `phone_no`, `id_number`, `user_type`, `email`, `password`) VALUES
(6, 'Shawn', 'Mbuvi', '0727088016', '29501445', 'ambassador', 'shawnmbuvi@gmail.com', 'CpaKXSxtQCGAs7IIOaj2pA=='),
(8, 'mbuvi', 'ngutu', '0722990089', '267190202', 'supporter', 'shawnmbuvi1@gmail.com', 'gdyb21LQTcIANtvYMT7QVQ=='),
(13, 'Shawn', 'Andre', '0731628560', '29501445', 'ambassador', 'seanandre30@gmail.com', 'gdyb21LQTcIANtvYMT7QVQ=='),
(16, 'Shawn_Supporter', 'Andre_Supporter', '0731628560', '29501448', 'supporter', 'supporterandre31@gmail.com', 'gdyb21LQTcIANtvYMT7QVQ=='),
(17, 'Shawn30', 'Andre50', '0731628560', '12345', 'ambassador', 'seanandre308@gmail.com', 'gdyb21LQTcIANtvYMT7QVQ=='),
(19, 'Shawn30', 'Andre50', '0731628560', '12345', 'ambassador', 'seanandre3908@gmail.com', 'gdyb21LQTcIANtvYMT7QVQ==');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `agents`
--
ALTER TABLE `agents`
  ADD PRIMARY KEY (`a_id`),
  ADD UNIQUE KEY `agent_email_id` (`agent_email_id`);

--
-- Indexes for table `agent_transactions`
--
ALTER TABLE `agent_transactions`
  ADD PRIMARY KEY (`t_id`),
  ADD KEY `fk_service_transactions` (`service_id`),
  ADD KEY `fk_agent_refs` (`agent_id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`s_id`),
  ADD UNIQUE KEY `service_code` (`service_code`);

--
-- Indexes for table `supporters`
--
ALTER TABLE `supporters`
  ADD PRIMARY KEY (`s_id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`t_id`),
  ADD KEY `service_code` (`service_code`),
  ADD KEY `service_code_2` (`service_code`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`u_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `agents`
--
ALTER TABLE `agents`
  MODIFY `a_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `agent_transactions`
--
ALTER TABLE `agent_transactions`
  MODIFY `t_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `s_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `supporters`
--
ALTER TABLE `supporters`
  MODIFY `s_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `t_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `u_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `agent_transactions`
--
ALTER TABLE `agent_transactions`
  ADD CONSTRAINT `fk_agent_refs` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`a_id`),
  ADD CONSTRAINT `fk_service_transactions` FOREIGN KEY (`service_id`) REFERENCES `services` (`s_id`);

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`service_code`) REFERENCES `services` (`service_code`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
